function main() {
   // Widget instantiation metadata...
   var widget = {
      id : "ConsoleTrashcan", 
      name : "Alfresco.ConsoleTrashcan"
   };
   model.widgets = [widget];
}
main();