function main() {
   // Widget instantiation metadata...
   var widget = {
      id : "ConsoleNodeBrowser", 
      name : "Alfresco.ConsoleNodeBrowser"
   };
   model.widgets = [widget];
}
main();