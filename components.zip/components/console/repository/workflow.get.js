<import resource="classpath:/alfresco/templates/org/alfresco/import/alfresco-util.js">

function main()
{
   model.activitiAdminUrl = AlfrescoUtil.getActivitiAdminUrl();
}

main();